export interface User {
  id: string;
  username: string;
  nickname: string;
  avatar: string;
  bio: string;
  followers: number;
  following: number;
  posts: number;
  joinDate: string;
  tags: string[];
}

export interface Comment {
  id: string;
  postId: string;
  userId: string;
  username: string;
  avatar: string;
  content: string;
  createdAt: string;
  likes: number;
  liked: boolean;
  replies?: Comment[];
}

export interface Post {
  id: string;
  userId: string;
  username: string;
  avatar: string;
  content: string;
  images: string[];
  tags: string[];
  likes: number;
  comments: number;
  shares: number;
  liked: boolean;
  collected: boolean;
  createdAt: string;
  category: string;
}

export interface Notification {
  id: string;
  type: 'like' | 'comment' | 'follow' | 'system';
  fromUserId: string;
  fromUsername: string;
  fromAvatar: string;
  content: string;
  createdAt: string;
  read: boolean;
}
