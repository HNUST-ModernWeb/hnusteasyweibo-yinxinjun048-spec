import { Link } from 'react-router-dom';
import { Post } from '../types';
import { useApp } from '../context/AppContext';

function formatTime(dateStr: string): string {
  const now = Date.now();
  const date = new Date(dateStr).getTime();
  const diff = now - date;
  const minutes = Math.floor(diff / 60000);
  if (minutes < 1) return '刚刚';
  if (minutes < 60) return `${minutes}分钟前`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}小时前`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days}天前`;
  const months = Math.floor(days / 30);
  return `${months}个月前`;
}

export default function PostCard({ post }: { post: Post }) {
  const { toggleLike, toggleCollect, user, setShowLoginModal } = useApp();

  const handleLike = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!user) { setShowLoginModal(true); return; }
    toggleLike(post.id);
  };

  const handleCollect = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!user) { setShowLoginModal(true); return; }
    toggleCollect(post.id);
  };

  return (
    <Link to={`/post/${post.id}`} className="block group">
      <article className="bg-white rounded-2xl p-5 sm:p-6 border border-gray-100 hover:border-indigo-100 hover:shadow-lg hover:shadow-indigo-50 transition-all duration-300">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <span className="text-3xl group-hover:scale-110 transition-transform duration-300">{post.avatar}</span>
            <div>
              <p className="font-semibold text-gray-900 text-sm">{post.username}</p>
              <p className="text-xs text-gray-400">{formatTime(post.createdAt)}</p>
            </div>
          </div>
          {post.category && (
            <span className="px-2.5 py-1 bg-indigo-50 text-indigo-600 text-xs font-medium rounded-full">
              {post.category}
            </span>
          )}
        </div>

        {/* Content */}
        <div className="mb-4">
          <p className="text-gray-800 text-[15px] leading-relaxed whitespace-pre-line">
            {post.content.length > 280 ? (
              <>
                {post.content.slice(0, 280)}...
                <span className="text-indigo-600 hover:text-indigo-700 ml-1 font-medium">展开全文</span>
              </>
            ) : (
              post.content
            )}
          </p>
        </div>

        {/* Images placeholder */}
        {post.images && post.images.length > 0 && (
          <div className="mb-4 grid gap-2" style={{
            gridTemplateColumns: post.images.length === 1 ? '1fr' : 'repeat(2, 1fr)'
          }}>
            {post.images.map((img, i) => (
              <div key={i} className="aspect-square bg-gradient-to-br from-gray-100 to-gray-200 rounded-xl flex items-center justify-center text-gray-400 text-sm">
                {img}
              </div>
            ))}
          </div>
        )}

        {/* Tags */}
        {post.tags && post.tags.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-4">
            {post.tags.map((tag) => (
              <span
                key={tag}
                className="px-2.5 py-0.5 bg-gray-50 text-gray-500 text-xs rounded-full hover:bg-indigo-50 hover:text-indigo-600 transition-colors cursor-pointer"
                onClick={(e) => e.preventDefault()}
              >
                #{tag}
              </span>
            ))}
          </div>
        )}

        {/* Actions */}
        <div className="flex items-center gap-1 sm:gap-2 pt-3 border-t border-gray-50">
          <button
            onClick={handleLike}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm transition-all duration-200 ${
              post.liked
                ? 'text-red-500 bg-red-50 hover:bg-red-100'
                : 'text-gray-500 hover:bg-gray-50 hover:text-red-500'
            }`}
          >
            <svg className="w-[18px] h-[18px]" fill={post.liked ? 'currentColor' : 'none'} stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={post.liked ? 0 : 2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
            </svg>
            <span className="font-medium">{post.likes}</span>
          </button>

          <Link
            to={`/post/${post.id}`}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm text-gray-500 hover:bg-gray-50 hover:text-indigo-500 transition-all duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            <svg className="w-[18px] h-[18px]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
            </svg>
            <span className="font-medium">{post.comments}</span>
          </Link>

          <button
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm text-gray-500 hover:bg-gray-50 hover:text-green-500 transition-all duration-200"
            onClick={(e) => { e.preventDefault(); e.stopPropagation(); }}
          >
            <svg className="w-[18px] h-[18px]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
            </svg>
            <span className="font-medium">{post.shares}</span>
          </button>

          <div className="flex-1" />

          <button
            onClick={handleCollect}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm transition-all duration-200 ${
              post.collected
                ? 'text-amber-500 bg-amber-50 hover:bg-amber-100'
                : 'text-gray-500 hover:bg-gray-50 hover:text-amber-500'
            }`}
          >
            <svg className="w-[18px] h-[18px]" fill={post.collected ? 'currentColor' : 'none'} stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={post.collected ? 0 : 2} d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
            </svg>
            <span className="font-medium hidden sm:inline">{post.collected ? '已收藏' : '收藏'}</span>
          </button>
        </div>
      </article>
    </Link>
  );
}
