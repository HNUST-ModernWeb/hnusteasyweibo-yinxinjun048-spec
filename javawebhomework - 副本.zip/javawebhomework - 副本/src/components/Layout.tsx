import { useState } from 'react';
import {
  Home, PenSquare, User, Bell, Search, Menu, X,
  LogOut, Bookmark, Compass, TrendingUp
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { cn } from '../utils/cn';

interface LayoutProps {
  children: React.ReactNode;
  currentPage: string;
  onNavigate: (page: string) => void;
}

export default function Layout({ children, currentPage, onNavigate }: LayoutProps) {
  const { currentUser, notifications, isLoggedIn, logout } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const unreadCount = notifications.filter(n => !n.read).length;

  const navItems = [
    { id: 'home', label: '首页', icon: Home },
    { id: 'explore', label: '发现', icon: Compass },
    { id: 'publish', label: '发布', icon: PenSquare, highlight: true },
    { id: 'notifications', label: '通知', icon: Bell, badge: unreadCount },
    { id: 'profile', label: '我的', icon: User },
  ];

  const handleNavClick = (page: string) => {
    onNavigate(page);
    setMobileMenuOpen(false);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      onNavigate('explore');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top Navigation Bar */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-lg border-b border-gray-200/60 shadow-sm">
        <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
          {/* Logo */}
          <button
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-2 hover:opacity-80 transition-opacity"
          >
            <div className="w-9 h-9 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/25">
              <TrendingUp className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent hidden sm:block">
              社区圈
            </span>
          </button>

          {/* Search Bar */}
          <form onSubmit={handleSearch} className="hidden md:flex flex-1 max-w-md mx-6">
            <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="搜索话题、用户..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-gray-100 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/40 focus:bg-white transition-all border border-transparent focus:border-blue-200"
              />
            </div>
          </form>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-1">
            {navItems.map(item => {
              const Icon = item.icon;
              const isActive = currentPage === item.id || (item.id === 'profile' && currentPage === 'profile');
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={cn(
                    'relative flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all',
                    item.highlight
                      ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg shadow-blue-500/25 hover:shadow-blue-500/40 hover:scale-105'
                      : isActive
                        ? 'bg-blue-50 text-blue-600'
                        : 'text-gray-600 hover:bg-gray-100'
                  )}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                  {item.badge ? (
                    <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center animate-pulse">
                      {item.badge}
                    </span>
                  ) : null}
                </button>
              );
            })}
          </nav>

          {/* User Avatar & Mobile Menu */}
          <div className="flex items-center gap-3 md:hidden">
            {isLoggedIn ? (
              <>
                <button
                  onClick={() => handleNavClick('notifications')}
                  className="relative p-2 rounded-full hover:bg-gray-100 transition"
                >
                  <Bell className="w-5 h-5 text-gray-600" />
                  {unreadCount > 0 && (
                    <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-red-500 rounded-full animate-pulse" />
                  )}
                </button>
                <button
                  onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                  className="p-2 rounded-full hover:bg-gray-100 transition"
                >
                  {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
                </button>
              </>
            ) : (
              <button
                onClick={() => handleNavClick('login')}
                className="px-4 py-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-full text-sm font-medium shadow-lg"
              >
                登录
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Mobile Menu Overlay */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div className="absolute inset-0 bg-black/20 backdrop-blur-sm" onClick={() => setMobileMenuOpen(false)} />
          <div className="absolute right-0 top-16 w-72 bg-white shadow-xl rounded-bl-2xl border-l border-b border-gray-100 p-4 animate-in slide-in-from-right">
            {/* User Info */}
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl mb-4">
              <div className={cn('w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm', currentUser.avatar)}>
                {currentUser.displayName[0]}
              </div>
              <div>
                <p className="font-medium text-gray-900">{currentUser.displayName}</p>
                <p className="text-xs text-gray-500">@{currentUser.username}</p>
              </div>
            </div>

            {/* Menu Items */}
            <div className="space-y-1">
              {navItems.map(item => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleNavClick(item.id)}
                    className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-gray-700 hover:bg-gray-50 transition text-left"
                  >
                    <Icon className="w-5 h-5" />
                    <span className="text-sm font-medium">{item.label}</span>
                    {item.id === 'notifications' && unreadCount > 0 && (
                      <span className="ml-auto w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                        {unreadCount}
                      </span>
                    )}
                  </button>
                );
              })}
              <button
                onClick={() => { logout(); handleNavClick('home'); }}
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-red-600 hover:bg-red-50 transition"
              >
                <LogOut className="w-5 h-5" />
                <span className="text-sm font-medium">退出登录</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-6">
        <div className="flex gap-6">
          {/* Content Area */}
          <div className="flex-1 min-w-0">
            {children}
          </div>

          {/* Sidebar - Desktop Only */}
          <aside className="hidden lg:block w-72 flex-shrink-0 space-y-4">
            {/* User Card */}
            {isLoggedIn && (
              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                <div className="h-20 bg-gradient-to-r from-blue-500 to-purple-600" />
                <div className="px-4 pb-4">
                  <div className="flex items-end gap-3 -mt-8">
                    <div className={cn('w-14 h-14 rounded-full flex items-center justify-center text-white text-xl font-bold ring-4 ring-white shadow-lg', currentUser.avatar)}>
                      {currentUser.displayName[0]}
                    </div>
                  </div>
                  <div className="mt-2">
                    <h3 className="font-bold text-gray-900">{currentUser.displayName}</h3>
                    <p className="text-xs text-gray-500">@{currentUser.username}</p>
                    <p className="text-sm text-gray-600 mt-1 line-clamp-2">{currentUser.bio}</p>
                  </div>
                  <div className="flex justify-between mt-3 pt-3 border-t border-gray-100">
                    <button onClick={() => handleNavClick('profile')} className="text-center">
                      <p className="font-bold text-gray-900">{currentUser.postCount}</p>
                      <p className="text-xs text-gray-500">动态</p>
                    </button>
                    <div className="text-center">
                      <p className="font-bold text-gray-900">{currentUser.followers}</p>
                      <p className="text-xs text-gray-500">粉丝</p>
                    </div>
                    <div className="text-center">
                      <p className="font-bold text-gray-900">{currentUser.following}</p>
                      <p className="text-xs text-gray-500">关注</p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Quick Actions */}
            {isLoggedIn && (
              <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => handleNavClick('publish')}
                    className="flex items-center gap-2 px-3 py-2.5 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-xl text-sm font-medium shadow-lg shadow-blue-500/20 hover:shadow-blue-500/30 transition-all hover:scale-[1.02] active:scale-[0.98]"
                  >
                    <PenSquare className="w-4 h-4" />
                    发布
                  </button>
                  <button
                    onClick={() => handleNavClick('home')}
                    className="flex items-center gap-2 px-3 py-2.5 bg-gray-100 text-gray-700 rounded-xl text-sm font-medium hover:bg-gray-200 transition"
                  >
                    <Bookmark className="w-4 h-4" />
                    收藏
                  </button>
                </div>
              </div>
            )}

            {/* Trending */}
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
              <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-orange-500" />
                热门话题
              </h3>
              <div className="space-y-3">
                {[
                  { name: '前端开发', count: '12.3万' },
                  { name: 'AI人工智能', count: '45.6万' },
                  { name: 'Vue3实战', count: '8.9万' },
                  { name: 'Spring Boot', count: '23.4万' },
                  { name: '全栈之路', count: '6.7万' },
                ].map((topic, i) => (
                  <button
                    key={topic.name}
                    onClick={() => handleNavClick('explore')}
                    className="w-full text-left hover:bg-gray-50 rounded-lg p-2 -mx-2 transition group"
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-gray-400 w-4">{i + 1}</span>
                      <div>
                        <p className="text-sm font-medium text-gray-900 group-hover:text-blue-600 transition">
                          #{topic.name}
                        </p>
                        <p className="text-xs text-gray-400">{topic.count} 讨论</p>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Footer */}
            <div className="text-xs text-gray-400 px-2 space-y-1">
              <div className="flex flex-wrap gap-x-3 gap-y-1">
                <span>关于我们</span>
                <span>帮助中心</span>
                <span>隐私政策</span>
                <span>服务条款</span>
              </div>
              <p>© 2024 社区圈 · 全栈学习实践项目</p>
            </div>
          </aside>
        </div>
      </main>

      {/* Mobile Bottom Navigation */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white/90 backdrop-blur-lg border-t border-gray-200 z-50 safe-area-inset">
        <div className="flex items-center justify-around h-16 px-2">
          {navItems.filter(item => !item.highlight).map(item => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={cn(
                  'relative flex flex-col items-center gap-0.5 px-3 py-1 rounded-lg transition-all min-w-[3.5rem]',
                  isActive ? 'text-blue-600' : 'text-gray-500 hover:text-gray-700'
                )}
              >
                <Icon className={cn('w-5 h-5', isActive && 'scale-110 transition-transform')} />
                <span className="text-[10px] font-medium">{item.label}</span>
                {item.badge ? (
                  <span className="absolute top-0 right-1 w-4 h-4 bg-red-500 text-white text-[10px] rounded-full flex items-center justify-center">
                    {item.badge}
                  </span>
                ) : null}
              </button>
            );
          })}
          {/* Publish FAB */}
          <button
            onClick={() => handleNavClick('publish')}
            className="flex items-center justify-center w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full shadow-lg shadow-blue-500/30 -mt-4 hover:shadow-blue-500/50 transition-all active:scale-95"
          >
            <PenSquare className="w-5 h-5 text-white" />
          </button>
        </div>
      </nav>
    </div>
  );
}
