import {
  Bell, Heart, MessageCircle, UserPlus, AtSign, CheckCheck
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { cn } from '../utils/cn';

interface NotificationsProps {
  onNavigate: (page: string, data?: Record<string, string>) => void;
}

export default function Notifications({ onNavigate }: NotificationsProps) {
  const { notifications, markNotificationRead, markAllNotificationsRead, users, toggleFollow } = useApp();

  const unreadCount = notifications.filter(n => !n.read).length;

  const getIcon = (type: string) => {
    switch (type) {
      case 'like': return <Heart className="w-4 h-4 text-red-500 fill-red-500" />;
      case 'comment': return <MessageCircle className="w-4 h-4 text-blue-500" />;
      case 'follow': return <UserPlus className="w-4 h-4 text-green-500" />;
      case 'mention': return <AtSign className="w-4 h-4 text-purple-500" />;
      default: return <Bell className="w-4 h-4 text-gray-500" />;
    }
  };

  const getBgColor = (type: string) => {
    switch (type) {
      case 'like': return 'bg-red-50';
      case 'comment': return 'bg-blue-50';
      case 'follow': return 'bg-green-50';
      case 'mention': return 'bg-purple-50';
      default: return 'bg-gray-50';
    }
  };

  const handleClick = (notification: typeof notifications[0]) => {
    markNotificationRead(notification.id);
    if (notification.postId) {
      onNavigate('post', { postId: notification.postId });
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-4 pb-20 md:pb-0">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-blue-500" />
            <h1 className="text-lg font-bold text-gray-900">通知</h1>
            {unreadCount > 0 && (
              <span className="px-2 py-0.5 bg-red-500 text-white text-xs rounded-full font-medium">
                {unreadCount}
              </span>
            )}
          </div>
          {unreadCount > 0 && (
            <button
              onClick={markAllNotificationsRead}
              className="flex items-center gap-1 text-sm text-blue-500 hover:text-blue-600 transition"
            >
              <CheckCheck className="w-4 h-4" />
              全部已读
            </button>
          )}
        </div>
      </div>

      {/* Notification List */}
      {notifications.length > 0 ? (
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden divide-y divide-gray-50">
          {notifications.map(notification => {
            const fromUser = users.find(u => u.id === notification.fromUser.id) || notification.fromUser;
            return (
              <button
                key={notification.id}
                onClick={() => handleClick(notification)}
                className={cn(
                  'w-full flex items-start gap-3 p-4 text-left hover:bg-gray-50 transition',
                  !notification.read && 'bg-blue-50/30'
                )}
              >
                {/* Avatar */}
                <div className="relative flex-shrink-0">
                  <div className={cn(
                    'w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm',
                    fromUser.avatar
                  )}>
                    {fromUser.displayName[0]}
                  </div>
                  <div className={cn(
                    'absolute -bottom-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center',
                    getBgColor(notification.type)
                  )}>
                    {getIcon(notification.type)}
                  </div>
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-gray-800">
                    <span className="font-semibold">{fromUser.displayName}</span>
                    {' '}{notification.content}
                  </p>
                  <p className="text-xs text-gray-400 mt-1">{notification.createdAt}</p>
                </div>

                {/* Unread indicator */}
                {!notification.read && (
                  <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0" />
                )}

                {/* Follow button */}
                {notification.type === 'follow' && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleFollow(fromUser.id);
                    }}
                    className={cn(
                      'px-3 py-1 rounded-full text-xs font-medium flex-shrink-0 transition',
                      fromUser.isFollowing
                        ? 'bg-gray-100 text-gray-600'
                        : 'bg-blue-500 text-white'
                    )}
                  >
                    {fromUser.isFollowing ? '已关注' : '关注'}
                  </button>
                )}
              </button>
            );
          })}
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-12 text-center">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Bell className="w-8 h-8 text-gray-300" />
          </div>
          <p className="text-gray-500 text-lg font-medium">暂无通知</p>
          <p className="text-gray-400 text-sm mt-1">当有人与你的内容互动时，你会在这里看到</p>
        </div>
      )}
    </div>
  );
}
