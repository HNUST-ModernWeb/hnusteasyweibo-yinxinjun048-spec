import { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import PostCard from '../components/PostCard';
import { categories } from '../data/mockData';

export default function Home() {
  const { posts } = useApp();
  const [activeCategory, setActiveCategory] = useState('all');
  const [sortBy, setSortBy] = useState<'latest' | 'hot'>('latest');

  const filteredPosts = useMemo(() => {
    let filtered = posts;
    if (activeCategory !== 'all') {
      filtered = filtered.filter((p) => p.category === activeCategory);
    }
    if (sortBy === 'hot') {
      return [...filtered].sort((a, b) => b.likes - a.likes);
    }
    return filtered;
  }, [posts, activeCategory, sortBy]);

  const trendingTags = useMemo(() => {
    const tagCount: Record<string, number> = {};
    posts.forEach((p) => p.tags?.forEach((t) => { tagCount[t] = (tagCount[t] || 0) + 1; }));
    return Object.entries(tagCount)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 8);
  }, [posts]);

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-4 sm:py-6">
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Main Feed */}
        <div className="lg:col-span-3 space-y-4">
          {/* Category Filter */}
          <div className="bg-white rounded-2xl p-4 border border-gray-100">
            <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-hide">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-medium whitespace-nowrap transition-all duration-200 ${
                    activeCategory === cat.id
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-200'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  <span>{cat.icon}</span>
                  {cat.name}
                </button>
              ))}
            </div>
          </div>

          {/* Sort Bar */}
          <div className="flex items-center justify-between bg-white rounded-2xl px-5 py-3 border border-gray-100">
            <div className="flex items-center gap-4">
              <button
                onClick={() => setSortBy('latest')}
                className={`text-sm font-medium transition-colors ${
                  sortBy === 'latest' ? 'text-indigo-600' : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                最新发布
              </button>
              <div className="w-px h-4 bg-gray-200" />
              <button
                onClick={() => setSortBy('hot')}
                className={`text-sm font-medium transition-colors ${
                  sortBy === 'hot' ? 'text-indigo-600' : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                🔥 热门排序
              </button>
            </div>
            <span className="text-xs text-gray-400">共 {filteredPosts.length} 条内容</span>
          </div>

          {/* Posts */}
          <div className="space-y-4">
            {filteredPosts.length > 0 ? (
              filteredPosts.map((post) => <PostCard key={post.id} post={post} />)
            ) : (
              <div className="bg-white rounded-2xl p-12 border border-gray-100 text-center">
                <span className="text-5xl block mb-4">📭</span>
                <h3 className="text-lg font-semibold text-gray-700 mb-2">暂无内容</h3>
                <p className="text-gray-400 text-sm">该分类下还没有发布任何内容</p>
              </div>
            )}
          </div>
        </div>

        {/* Sidebar */}
        <div className="hidden lg:block space-y-4">
          {/* Hot Tags */}
          <div className="bg-white rounded-2xl p-5 border border-gray-100 sticky top-20">
            <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
              <span className="text-lg">🔥</span> 热门话题
            </h3>
            <div className="flex flex-wrap gap-2">
              {trendingTags.map(([tag, count]) => (
                <span
                  key={tag}
                  className="px-3 py-1.5 bg-gray-50 hover:bg-indigo-50 text-gray-600 hover:text-indigo-600 text-sm rounded-full cursor-pointer transition-colors"
                >
                  #{tag}
                  <span className="text-xs text-gray-400 ml-1">{count}</span>
                </span>
              ))}
            </div>
          </div>

          {/* Quick Stats */}
          <div className="bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl p-5 text-white sticky top-[calc(20px+200px+16px)]">
            <h3 className="font-semibold mb-3">📊 社区统计</h3>
            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-indigo-200">总内容数</span>
                <span className="font-medium">{posts.length}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-indigo-200">总互动量</span>
                <span className="font-medium">{posts.reduce((s, p) => s + p.likes + p.comments, 0)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-indigo-200">活跃用户</span>
                <span className="font-medium">{new Set(posts.map((p) => p.userId)).size}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
