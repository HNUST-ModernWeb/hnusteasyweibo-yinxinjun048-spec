import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import PostCard from '../components/PostCard';

export default function Profile() {
  const { user, posts, isLoggedIn, setShowLoginModal } = useApp();
  const [activeTab, setActiveTab] = useState<'posts' | 'liked' | 'collected'>('posts');

  if (!isLoggedIn || !user) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center">
        <span className="text-6xl block mb-6">🔒</span>
        <h2 className="text-2xl font-bold text-gray-900 mb-3">请先登录</h2>
        <p className="text-gray-500 mb-8">登录后即可查看个人主页</p>
        <button
          onClick={() => setShowLoginModal(true)}
          className="px-8 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-medium rounded-xl hover:shadow-lg hover:shadow-indigo-200 transition-all duration-200"
        >
          立即登录
        </button>
      </div>
    );
  }

  const userPosts = useMemo(() => posts.filter((p) => p.userId === user.id), [posts, user.id]);
  const likedPosts = useMemo(() => posts.filter((p) => p.liked), [posts]);
  const collectedPosts = useMemo(() => posts.filter((p) => p.collected), [posts]);

  const tabs = [
    { key: 'posts' as const, label: '我的发布', count: userPosts.length, icon: '📝' },
    { key: 'liked' as const, label: '我的点赞', count: likedPosts.length, icon: '❤️' },
    { key: 'collected' as const, label: '我的收藏', count: collectedPosts.length, icon: '⭐' },
  ];

  const currentPosts = activeTab === 'posts' ? userPosts : activeTab === 'liked' ? likedPosts : collectedPosts;

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('zh-CN', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-4 sm:py-8">
      {/* Profile Card */}
      <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden mb-6">
        {/* Cover */}
        <div className="h-32 sm:h-40 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 relative">
          <div className="absolute inset-0 bg-black/10" />
          {/* Decorative circles */}
          <div className="absolute top-4 right-8 w-20 h-20 bg-white/10 rounded-full" />
          <div className="absolute bottom-2 left-12 w-12 h-12 bg-white/10 rounded-full" />
        </div>

        {/* User Info */}
        <div className="px-6 sm:px-8 pb-6 relative">
          <div className="flex flex-col sm:flex-row sm:items-end gap-4 -mt-12 sm:-mt-10">
            <div className="w-24 h-24 bg-white rounded-2xl flex items-center justify-center text-5xl shadow-lg border-4 border-white">
              {user.avatar}
            </div>
            <div className="flex-1 sm:pb-1">
              <h1 className="text-xl sm:text-2xl font-bold text-gray-900">{user.nickname}</h1>
              <p className="text-sm text-gray-400">@{user.username}</p>
            </div>
            <Link
              to="/publish"
              className="px-5 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white text-sm font-medium rounded-xl hover:shadow-lg hover:shadow-indigo-200 transition-all duration-200"
            >
              ✏️ 发布内容
            </Link>
          </div>

          {/* Bio */}
          <p className="mt-4 text-gray-600 text-sm leading-relaxed">{user.bio}</p>

          {/* Stats */}
          <div className="flex items-center gap-6 mt-5 pt-5 border-t border-gray-100">
            <div className="text-center">
              <p className="text-lg font-bold text-gray-900">{user.posts}</p>
              <p className="text-xs text-gray-400">发布</p>
            </div>
            <div className="w-px h-8 bg-gray-100" />
            <div className="text-center">
              <p className="text-lg font-bold text-gray-900">{user.followers}</p>
              <p className="text-xs text-gray-400">粉丝</p>
            </div>
            <div className="w-px h-8 bg-gray-100" />
            <div className="text-center">
              <p className="text-lg font-bold text-gray-900">{user.following}</p>
              <p className="text-xs text-gray-400">关注</p>
            </div>
            <div className="w-px h-8 bg-gray-100" />
            <div className="text-center">
              <p className="text-sm font-medium text-gray-500">
                📅 {formatDate(user.joinDate)} 加入
              </p>
            </div>
          </div>

          {/* Tags */}
          {user.tags && user.tags.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-4">
              {user.tags.map((tag) => (
                <span
                  key={tag}
                  className="px-3 py-1 bg-indigo-50 text-indigo-600 text-xs font-medium rounded-full"
                >
                  {tag}
                </span>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white rounded-2xl border border-gray-100 mb-6 overflow-hidden">
        <div className="flex border-b border-gray-100">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`flex-1 flex items-center justify-center gap-2 px-4 py-4 text-sm font-medium transition-all duration-200 relative ${
                activeTab === tab.key
                  ? 'text-indigo-600'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <span>{tab.icon}</span>
              {tab.label}
              <span className={`text-xs px-1.5 py-0.5 rounded-full ${
                activeTab === tab.key ? 'bg-indigo-100 text-indigo-600' : 'bg-gray-100 text-gray-400'
              }`}>
                {tab.count}
              </span>
              {activeTab === tab.key && (
                <div className="absolute bottom-0 left-1/4 right-1/4 h-0.5 bg-indigo-600 rounded-full" />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Posts List */}
      <div className="space-y-4">
        {currentPosts.length > 0 ? (
          currentPosts.map((post) => <PostCard key={post.id} post={post} />)
        ) : (
          <div className="bg-white rounded-2xl p-12 border border-gray-100 text-center">
            <span className="text-5xl block mb-4">
              {activeTab === 'posts' ? '📝' : activeTab === 'liked' ? '❤️' : '⭐'}
            </span>
            <h3 className="text-lg font-semibold text-gray-700 mb-2">
              {activeTab === 'posts' ? '还没有发布内容' : activeTab === 'liked' ? '还没有点赞的内容' : '还没有收藏的内容'}
            </h3>
            <p className="text-gray-400 text-sm mb-4">
              {activeTab === 'posts' ? '点击下方按钮发布你的第一条内容吧' : '去首页看看有什么感兴趣的内容'}
            </p>
            {activeTab === 'posts' ? (
              <Link
                to="/publish"
                className="inline-block px-6 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white text-sm font-medium rounded-xl hover:shadow-lg hover:shadow-indigo-200 transition-all"
              >
                发布内容
              </Link>
            ) : (
              <Link
                to="/"
                className="inline-block px-6 py-2 bg-gray-100 text-gray-600 text-sm font-medium rounded-xl hover:bg-gray-200 transition-colors"
              >
                浏览首页
              </Link>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
