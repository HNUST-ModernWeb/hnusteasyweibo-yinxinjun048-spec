import { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import PostCard from '../components/PostCard';

export default function Search() {
  const { posts } = useApp();
  const [query, setQuery] = useState('');

  const results = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase().trim();
    return posts.filter(
      (p) =>
        p.content.toLowerCase().includes(q) ||
        p.username.toLowerCase().includes(q) ||
        p.tags?.some((t) => t.toLowerCase().includes(q)) ||
        p.category?.toLowerCase().includes(q)
    );
  }, [posts, query]);

  const allTags = useMemo(() => {
    const tagCount: Record<string, number> = {};
    posts.forEach((p) => p.tags?.forEach((t) => { tagCount[t] = (tagCount[t] || 0) + 1; }));
    return Object.entries(tagCount).sort((a, b) => b[1] - a[1]);
  }, [posts]);

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-4 sm:py-8">
      {/* Search Bar */}
      <div className="bg-white rounded-2xl border border-gray-100 p-6 mb-6">
        <div className="flex items-center gap-3">
          <svg className="w-5 h-5 text-gray-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="flex-1 text-lg outline-none text-gray-800 placeholder-gray-400"
            placeholder="搜索内容、标签、用户..."
            autoFocus
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1.5 hover:bg-gray-100 rounded-full text-gray-400 transition-colors"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          )}
        </div>
      </div>

      {/* Results */}
      {query.trim() ? (
        <div>
          <p className="text-sm text-gray-500 mb-4">
            找到 <span className="font-semibold text-indigo-600">{results.length}</span> 条相关结果
          </p>
          <div className="space-y-4">
            {results.length > 0 ? (
              results.map((post) => <PostCard key={post.id} post={post} />)
            ) : (
              <div className="bg-white rounded-2xl p-12 border border-gray-100 text-center">
                <span className="text-5xl block mb-4">🔍</span>
                <h3 className="text-lg font-semibold text-gray-700 mb-2">未找到相关内容</h3>
                <p className="text-gray-400 text-sm">试试其他关键词或浏览热门标签</p>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div>
          {/* Hot Tags */}
          <div className="bg-white rounded-2xl border border-gray-100 p-6 mb-6">
            <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
              <span>🔥</span> 热门标签
            </h3>
            <div className="flex flex-wrap gap-2">
              {allTags.map(([tag, count]) => (
                <button
                  key={tag}
                  onClick={() => setQuery(tag)}
                  className="px-4 py-2 bg-gray-50 hover:bg-indigo-50 text-gray-600 hover:text-indigo-600 text-sm rounded-xl transition-colors flex items-center gap-2"
                >
                  #{tag}
                  <span className="text-xs text-gray-400">{count}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Search Tips */}
          <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-2xl p-6 border border-indigo-100/50">
            <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
              <span>💡</span> 搜索技巧
            </h3>
            <ul className="space-y-2 text-sm text-gray-600">
              <li className="flex items-start gap-2">
                <span className="text-indigo-500 mt-0.5">•</span>
                输入关键词搜索帖子的标题和内容
              </li>
              <li className="flex items-start gap-2">
                <span className="text-indigo-500 mt-0.5">•</span>
                可以搜索用户名来查找特定用户的内容
              </li>
              <li className="flex items-start gap-2">
                <span className="text-indigo-500 mt-0.5">•</span>
                点击热门标签可以快速查看相关内容
              </li>
              <li className="flex items-start gap-2">
                <span className="text-indigo-500 mt-0.5">•</span>
                支持搜索分类名称如"技术讨论"、"项目展示"等
              </li>
            </ul>
          </div>
        </div>
      )}
    </div>
  );
}
