import { useState, useMemo } from 'react';
import { Search, TrendingUp, Hash, Users, Sparkles } from 'lucide-react';
import { useApp } from '../context/AppContext';
import PostCard from '../components/PostCard';
import { cn } from '../utils/cn';

interface ExploreProps {
  onNavigate: (page: string, data?: Record<string, string>) => void;
}

export default function Explore({ onNavigate }: ExploreProps) {
  const { posts, users, toggleFollow } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [activeSection, setActiveSection] = useState<'all' | 'posts' | 'users' | 'topics'>('all');

  const trendingTopics = useMemo(() => {
    const tagMap = new Map<string, number>();
    posts.forEach(p => p.tags.forEach(t => tagMap.set(t, (tagMap.get(t) || 0) + 1)));
    return Array.from(tagMap.entries())
      .sort((a, b) => b[1] - a[1])
      .map(([name, count]) => ({ name, count }));
  }, [posts]);

  const searchResults = useMemo(() => {
    if (!searchQuery.trim()) return { posts: [], users: [], topics: [] };

    const q = searchQuery.toLowerCase();
    return {
      posts: posts.filter(p =>
        p.content.toLowerCase().includes(q) ||
        p.tags.some(t => t.toLowerCase().includes(q))
      ),
      users: users.filter(u =>
        u.displayName.toLowerCase().includes(q) ||
        u.username.toLowerCase().includes(q)
      ),
      topics: trendingTopics.filter(t => t.name.toLowerCase().includes(q)),
    };
  }, [searchQuery, posts, users, trendingTopics]);

  const hasSearch = searchQuery.trim().length > 0;

  return (
    <div className="max-w-2xl mx-auto space-y-4 pb-20 md:pb-0">
      {/* Search Header */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="搜索话题、用户、内容..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3 bg-gray-50 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-200 focus:bg-white transition-all border border-transparent focus:border-blue-200"
            autoFocus
          />
        </div>
      </div>

      {hasSearch ? (
        <>
          {/* Filter Tabs */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-1.5">
            <div className="flex items-center gap-1">
              {[
                { id: 'all', label: '全部', count: searchResults.posts.length + searchResults.users.length + searchResults.topics.length },
                { id: 'posts', label: '内容', count: searchResults.posts.length },
                { id: 'users', label: '用户', count: searchResults.users.length },
                { id: 'topics', label: '话题', count: searchResults.topics.length },
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveSection(tab.id as typeof activeSection)}
                  className={cn(
                    'flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-sm font-medium transition-all',
                    activeSection === tab.id
                      ? 'bg-blue-50 text-blue-600'
                      : 'text-gray-500 hover:bg-gray-50'
                  )}
                >
                  {tab.label}
                  <span className="text-xs opacity-60">({tab.count})</span>
                </button>
              ))}
            </div>
          </div>

          {/* Search Results */}
          {(activeSection === 'all' || activeSection === 'topics') && searchResults.topics.length > 0 && (
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
              <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                <Hash className="w-4 h-4 text-blue-500" />
                相关话题
              </h3>
              <div className="flex flex-wrap gap-2">
                {searchResults.topics.map(topic => (
                  <span
                    key={topic.name}
                    className="px-3 py-1.5 bg-blue-50 text-blue-600 rounded-full text-sm font-medium hover:bg-blue-100 transition cursor-pointer"
                  >
                    #{topic.name} ({topic.count})
                  </span>
                ))}
              </div>
            </div>
          )}

          {(activeSection === 'all' || activeSection === 'users') && searchResults.users.length > 0 && (
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
              <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                <Users className="w-4 h-4 text-blue-500" />
                相关用户
              </h3>
              <div className="space-y-3">
                {searchResults.users.map(user => (
                  <div key={user.id} className="flex items-center justify-between">
                    <button
                      onClick={() => onNavigate('profile', { userId: user.id })}
                      className="flex items-center gap-3 hover:opacity-80 transition"
                    >
                      <div className={cn(
                        'w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm',
                        user.avatar
                      )}>
                        {user.displayName[0]}
                      </div>
                      <div className="text-left">
                        <p className="font-medium text-gray-900 text-sm">{user.displayName}</p>
                        <p className="text-xs text-gray-500">@{user.username} · {user.followers} 粉丝</p>
                      </div>
                    </button>
                    <button
                      onClick={() => toggleFollow(user.id)}
                      className={cn(
                        'px-3 py-1.5 rounded-full text-xs font-medium transition',
                        user.isFollowing
                          ? 'bg-gray-100 text-gray-600 hover:bg-red-50 hover:text-red-500'
                          : 'bg-blue-500 text-white hover:bg-blue-600'
                      )}
                    >
                      {user.isFollowing ? '已关注' : '+ 关注'}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {(activeSection === 'all' || activeSection === 'posts') && searchResults.posts.length > 0 && (
            <div className="space-y-4">
              {searchResults.posts.map(post => (
                <PostCard
                  key={post.id}
                  post={post}
                  onPostClick={(postId) => onNavigate('post', { postId })}
                />
              ))}
            </div>
          )}

          {searchResults.posts.length === 0 && searchResults.users.length === 0 && searchResults.topics.length === 0 && (
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-12 text-center">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Search className="w-8 h-8 text-gray-300" />
              </div>
              <p className="text-gray-500 text-lg font-medium">未找到相关结果</p>
              <p className="text-gray-400 text-sm mt-1">试试其他关键词</p>
            </div>
          )}
        </>
      ) : (
        <>
          {/* Trending Topics */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
            <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-orange-500" />
              热门话题
            </h3>
            <div className="space-y-3">
              {trendingTopics.map((topic, i) => (
                <button
                  key={topic.name}
                  onClick={() => setSearchQuery(topic.name)}
                  className="w-full flex items-center gap-3 p-2 -mx-1 rounded-lg hover:bg-gray-50 transition group"
                >
                  <span className={cn(
                    'w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0',
                    i < 3 ? 'bg-orange-50 text-orange-500' : 'bg-gray-100 text-gray-400'
                  )}>
                    {i + 1}
                  </span>
                  <div className="text-left flex-1">
                    <p className="text-sm font-medium text-gray-900 group-hover:text-blue-600 transition">#{topic.name}</p>
                    <p className="text-xs text-gray-400">{topic.count} 条内容</p>
                  </div>
                  <Sparkles className="w-4 h-4 text-gray-300 group-hover:text-blue-400 transition" />
                </button>
              ))}
            </div>
          </div>

          {/* Recommended Users */}
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4">
            <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
              <Users className="w-5 h-5 text-blue-500" />
              推荐关注
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {users.filter(u => u.id !== 'user-1').slice(0, 4).map(user => (
                <div
                  key={user.id}
                  className="flex items-center gap-3 p-3 rounded-xl border border-gray-100 hover:border-blue-200 hover:bg-blue-50/30 transition cursor-pointer"
                  onClick={() => onNavigate('profile', { userId: user.id })}
                >
                  <div className={cn(
                    'w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm flex-shrink-0',
                    user.avatar
                  )}>
                    {user.displayName[0]}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-gray-900 text-sm truncate">{user.displayName}</p>
                    <p className="text-xs text-gray-500">{user.followers} 粉丝</p>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleFollow(user.id);
                    }}
                    className={cn(
                      'px-2.5 py-1 rounded-full text-xs font-medium flex-shrink-0 transition',
                      user.isFollowing
                        ? 'bg-gray-100 text-gray-600'
                        : 'bg-blue-500 text-white'
                    )}
                  >
                    {user.isFollowing ? '已关注' : '关注'}
                  </button>
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
