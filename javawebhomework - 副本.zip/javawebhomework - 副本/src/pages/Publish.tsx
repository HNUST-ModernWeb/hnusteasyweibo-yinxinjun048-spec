import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { categories } from '../data/mockData';

export default function Publish() {
  const { addPost, user, setShowLoginModal } = useApp();
  const navigate = useNavigate();

  const [content, setContent] = useState('');
  const [category, setCategory] = useState('');
  const [tagInput, setTagInput] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [charCount, setCharCount] = useState(0);
  const [showSuccess, setShowSuccess] = useState(false);

  const maxChars = 1000;

  const handleContentChange = (value: string) => {
    if (value.length <= maxChars) {
      setContent(value);
      setCharCount(value.length);
      if (errors.content) setErrors((p) => ({ ...p, content: '' }));
    }
  };

  const addTag = () => {
    const tag = tagInput.trim();
    if (!tag) return;
    if (tags.includes(tag)) {
      setErrors((p) => ({ ...p, tag: '标签已存在' }));
      return;
    }
    if (tags.length >= 5) {
      setErrors((p) => ({ ...p, tag: '最多添加5个标签' }));
      return;
    }
    setTags([...tags, tag]);
    setTagInput('');
    if (errors.tag) setErrors((p) => ({ ...p, tag: '' }));
  };

  const removeTag = (tag: string) => {
    setTags(tags.filter((t) => t !== tag));
  };

  const handleTagKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      addTag();
    }
  };

  const validate = (): boolean => {
    const errs: Record<string, string> = {};
    if (!content.trim()) errs.content = '请输入内容';
    else if (content.trim().length < 10) errs.content = '内容至少10个字符';
    if (!category) errs.category = '请选择分类';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!user) {
      setShowLoginModal(true);
      return;
    }

    if (!validate()) return;

    setIsSubmitting(true);
    await new Promise((r) => setTimeout(r, 800));

    addPost(content, tags, category, []);
    setIsSubmitting(false);
    setShowSuccess(true);

    setTimeout(() => {
      navigate('/');
    }, 1500);
  };

  const insertEmoji = (emoji: string) => {
    handleContentChange(content + emoji);
  };

  const quickEmojis = ['💡', '🔥', '✅', '🎯', '📚', '🚀', '💪', '🎨', '⭐', '🐛', '💡', '📝'];

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-4 sm:py-8">
      {/* Success Toast */}
      {showSuccess && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-green-500 text-white px-6 py-3 rounded-xl shadow-lg flex items-center gap-2 animate-slide-down">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
          </svg>
          发布成功！正在跳转到首页...
        </div>
      )}

      <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
        {/* Header */}
        <div className="px-6 py-5 border-b border-gray-100 bg-gradient-to-r from-indigo-50 to-purple-50">
          <h1 className="text-xl font-bold text-gray-900 flex items-center gap-2">
            <span className="text-2xl">✏️</span> 发布新内容
          </h1>
          <p className="text-sm text-gray-500 mt-1">分享你的知识、经验和想法</p>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Category Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              选择分类 <span className="text-red-500">*</span>
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {categories.filter((c) => c.id !== 'all').map((cat) => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => { setCategory(cat.id); if (errors.category) setErrors((p) => ({ ...p, category: '' })); }}
                  className={`flex items-center gap-2 px-3 py-2 rounded-xl text-sm font-medium transition-all duration-200 ${
                    category === cat.id
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-200'
                      : 'bg-gray-50 text-gray-600 hover:bg-gray-100 border border-gray-200'
                  }`}
                >
                  <span>{cat.icon}</span>
                  {cat.name}
                </button>
              ))}
            </div>
            {errors.category && (
              <p className="mt-2 text-xs text-red-500 flex items-center gap-1">
                <span>⚠️</span> {errors.category}
              </p>
            )}
          </div>

          {/* Content */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-sm font-medium text-gray-700">
                内容 <span className="text-red-500">*</span>
              </label>
              <span className={`text-xs ${charCount > maxChars * 0.9 ? 'text-red-500' : 'text-gray-400'}`}>
                {charCount} / {maxChars}
              </span>
            </div>
            <textarea
              value={content}
              onChange={(e) => handleContentChange(e.target.value)}
              rows={10}
              className={`w-full px-4 py-3 rounded-xl border ${errors.content ? 'border-red-300 bg-red-50' : 'border-gray-200'} focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all text-sm resize-none leading-relaxed`}
              placeholder="分享你的想法、经验或知识...&#10;&#10;支持多行文本，尽量详细地描述你的内容，这样更多人能从中受益。"
            />
            {errors.content && (
              <p className="mt-2 text-xs text-red-500 flex items-center gap-1">
                <span>⚠️</span> {errors.content}
              </p>
            )}

            {/* Quick Emojis */}
            <div className="mt-2 flex items-center gap-1 flex-wrap">
              <span className="text-xs text-gray-400 mr-1">快捷表情:</span>
              {quickEmojis.map((emoji) => (
                <button
                  key={emoji}
                  type="button"
                  onClick={() => insertEmoji(emoji)}
                  className="w-7 h-7 flex items-center justify-center rounded hover:bg-gray-100 text-sm transition-colors"
                >
                  {emoji}
                </button>
              ))}
            </div>
          </div>

          {/* Tags */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              标签 <span className="text-xs text-gray-400 font-normal">(最多5个，回车添加)</span>
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={tagInput}
                onChange={(e) => { setTagInput(e.target.value); if (errors.tag) setErrors((p) => ({ ...p, tag: '' })); }}
                onKeyDown={handleTagKeyDown}
                className="flex-1 px-4 py-2 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all text-sm"
                placeholder="输入标签后按回车"
              />
              <button
                type="button"
                onClick={addTag}
                className="px-4 py-2 bg-gray-100 text-gray-600 rounded-xl text-sm font-medium hover:bg-gray-200 transition-colors"
              >
                添加
              </button>
            </div>
            {errors.tag && (
              <p className="mt-1 text-xs text-red-500 flex items-center gap-1">
                <span>⚠️</span> {errors.tag}
              </p>
            )}
            {tags.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-3">
                {tags.map((tag) => (
                  <span
                    key={tag}
                    className="inline-flex items-center gap-1 px-3 py-1 bg-indigo-50 text-indigo-600 text-sm rounded-full"
                  >
                    #{tag}
                    <button
                      type="button"
                      onClick={() => removeTag(tag)}
                      className="ml-0.5 hover:text-red-500 transition-colors"
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Image Upload (Simulated) */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">图片附件</label>
            <div className="border-2 border-dashed border-gray-200 rounded-xl p-6 text-center hover:border-indigo-300 hover:bg-indigo-50/30 transition-colors cursor-pointer">
              <svg className="w-8 h-8 text-gray-400 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
              <p className="text-sm text-gray-500">点击或拖拽上传图片</p>
              <p className="text-xs text-gray-400 mt-1">支持 JPG、PNG 格式，单张不超过 5MB</p>
            </div>
          </div>

          {/* Preview */}
          {content.trim() && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">预览</label>
              <div className="bg-gray-50 rounded-xl p-4 border border-gray-100">
                <div className="flex items-center gap-2 mb-3">
                  <span className="text-xl">🧑‍💻</span>
                  <span className="text-sm font-medium text-gray-700">创意小张</span>
                </div>
                <p className="text-sm text-gray-800 leading-relaxed whitespace-pre-line">{content}</p>
                {tags.length > 0 && (
                  <div className="flex flex-wrap gap-1 mt-3">
                    {tags.map((tag) => (
                      <span key={tag} className="text-xs text-indigo-500">#{tag}</span>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Submit */}
          <div className="flex items-center justify-between pt-4 border-t border-gray-100">
            <p className="text-xs text-gray-400">
              发布后将展示在社区信息流中，请确保内容符合社区规范
            </p>
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => navigate('/')}
                className="px-5 py-2.5 text-sm font-medium text-gray-600 bg-gray-100 rounded-xl hover:bg-gray-200 transition-colors"
              >
                取消
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-6 py-2.5 bg-gradient-to-r from-indigo-600 to-purple-600 text-white text-sm font-medium rounded-xl hover:shadow-lg hover:shadow-indigo-200 transition-all duration-200 disabled:opacity-60 disabled:cursor-not-allowed flex items-center gap-2"
              >
                {isSubmitting ? (
                  <>
                    <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                    </svg>
                    发布中...
                  </>
                ) : (
                  '发布内容'
                )}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
