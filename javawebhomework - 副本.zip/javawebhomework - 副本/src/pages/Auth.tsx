import { useState } from 'react';
import { Eye, EyeOff, LogIn, UserPlus, AlertCircle, CheckCircle, TrendingUp } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { cn } from '../utils/cn';

interface AuthProps {
  initialMode?: 'login' | 'register';
  onNavigate: (page: string) => void;
}

export default function Auth({ initialMode = 'login', onNavigate }: AuthProps) {
  const { login } = useApp();
  const [mode, setMode] = useState(initialMode);
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
    agreeTerms: false,
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');

  const validate = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!formData.username.trim()) {
      newErrors.username = '请输入用户名';
    } else if (formData.username.length < 3) {
      newErrors.username = '用户名至少3个字符';
    }

    if (mode === 'register' && !formData.email.trim()) {
      newErrors.email = '请输入邮箱';
    } else if (mode === 'register' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = '请输入有效的邮箱地址';
    }

    if (!formData.password) {
      newErrors.password = '请输入密码';
    } else if (formData.password.length < 6) {
      newErrors.password = '密码至少6个字符';
    }

    if (mode === 'register') {
      if (formData.password !== formData.confirmPassword) {
        newErrors.confirmPassword = '两次密码输入不一致';
      }
      if (!formData.agreeTerms) {
        newErrors.agreeTerms = '请同意用户协议';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));

    if (mode === 'login') {
      const success = login(formData.username, formData.password);
      if (success) {
        setSuccessMessage('登录成功！正在跳转...');
        setTimeout(() => onNavigate('home'), 1500);
      }
    } else {
      setSuccessMessage('注册成功！正在跳转...');
      setTimeout(() => onNavigate('home'), 1500);
    }
    setIsLoading(false);
  };

  const updateField = (field: string, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) setErrors(prev => ({ ...prev, [field]: '' }));
  };

  if (successMessage) {
    return (
      <div className="max-w-md mx-auto">
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-12 text-center">
          <div className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-10 h-10 text-green-500" />
          </div>
          <h2 className="text-xl font-bold text-gray-900">{successMessage}</h2>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto pb-20 md:pb-0">
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-500 to-purple-600 px-8 py-10 text-center text-white">
          <div className="w-14 h-14 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center mx-auto mb-4">
            <TrendingUp className="w-8 h-8" />
          </div>
          <h1 className="text-2xl font-bold">{mode === 'login' ? '欢迎回来' : '加入社区圈'}</h1>
          <p className="text-white/80 mt-2">
            {mode === 'login' ? '登录你的账号，继续探索精彩内容' : '创建账号，开始你的社交之旅'}
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {/* Username */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">用户名</label>
            <input
              type="text"
              value={formData.username}
              onChange={(e) => updateField('username', e.target.value)}
              placeholder="请输入用户名"
              className={cn(
                'w-full px-4 py-2.5 rounded-xl border-2 text-sm focus:outline-none transition-all',
                errors.username
                  ? 'border-red-200 focus:border-red-400 focus:ring-4 focus:ring-red-50'
                  : 'border-gray-200 focus:border-blue-300 focus:ring-4 focus:ring-blue-50'
              )}
            />
            {errors.username && (
              <p className="flex items-center gap-1 text-red-500 text-xs mt-1">
                <AlertCircle className="w-3 h-3" />{errors.username}
              </p>
            )}
          </div>

          {/* Email (Register only) */}
          {mode === 'register' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">邮箱</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => updateField('email', e.target.value)}
                placeholder="请输入邮箱地址"
                className={cn(
                  'w-full px-4 py-2.5 rounded-xl border-2 text-sm focus:outline-none transition-all',
                  errors.email
                    ? 'border-red-200 focus:border-red-400 focus:ring-4 focus:ring-red-50'
                    : 'border-gray-200 focus:border-blue-300 focus:ring-4 focus:ring-blue-50'
                )}
              />
              {errors.email && (
                <p className="flex items-center gap-1 text-red-500 text-xs mt-1">
                  <AlertCircle className="w-3 h-3" />{errors.email}
                </p>
              )}
            </div>
          )}

          {/* Password */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">密码</label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={formData.password}
                onChange={(e) => updateField('password', e.target.value)}
                placeholder="请输入密码"
                className={cn(
                  'w-full px-4 py-2.5 pr-10 rounded-xl border-2 text-sm focus:outline-none transition-all',
                  errors.password
                    ? 'border-red-200 focus:border-red-400 focus:ring-4 focus:ring-red-50'
                    : 'border-gray-200 focus:border-blue-300 focus:ring-4 focus:ring-blue-50'
                )}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            {errors.password && (
              <p className="flex items-center gap-1 text-red-500 text-xs mt-1">
                <AlertCircle className="w-3 h-3" />{errors.password}
              </p>
            )}

            {/* Password Strength Indicator (Register) */}
            {mode === 'register' && formData.password && (
              <div className="mt-2">
                <div className="flex gap-1">
                  {[1, 2, 3, 4].map(level => (
                    <div
                      key={level}
                      className={cn(
                        'h-1 flex-1 rounded-full transition-colors',
                        formData.password.length >= level * 4
                          ? formData.password.length >= 12 ? 'bg-green-500' :
                            formData.password.length >= 8 ? 'bg-yellow-500' : 'bg-red-400'
                          : 'bg-gray-200'
                      )}
                    />
                  ))}
                </div>
                <p className="text-xs text-gray-400 mt-1">
                  {formData.password.length >= 12 ? '密码强度：强' :
                   formData.password.length >= 8 ? '密码强度：中' :
                   formData.password.length >= 4 ? '密码强度：弱' : '密码太短'}
                </p>
              </div>
            )}
          </div>

          {/* Confirm Password (Register) */}
          {mode === 'register' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">确认密码</label>
              <input
                type="password"
                value={formData.confirmPassword}
                onChange={(e) => updateField('confirmPassword', e.target.value)}
                placeholder="请再次输入密码"
                className={cn(
                  'w-full px-4 py-2.5 rounded-xl border-2 text-sm focus:outline-none transition-all',
                  errors.confirmPassword
                    ? 'border-red-200 focus:border-red-400 focus:ring-4 focus:ring-red-50'
                    : 'border-gray-200 focus:border-blue-300 focus:ring-4 focus:ring-blue-50'
                )}
              />
              {errors.confirmPassword && (
                <p className="flex items-center gap-1 text-red-500 text-xs mt-1">
                  <AlertCircle className="w-3 h-3" />{errors.confirmPassword}
                </p>
              )}
            </div>
          )}

          {/* Terms (Register) */}
          {mode === 'register' && (
            <div>
              <label className="flex items-start gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.agreeTerms}
                  onChange={(e) => updateField('agreeTerms', e.target.checked)}
                  className="mt-1 w-4 h-4 rounded border-gray-300 text-blue-500 focus:ring-blue-500"
                />
                <span className="text-sm text-gray-600">
                  我已阅读并同意 <span className="text-blue-500">《用户协议》</span> 和 <span className="text-blue-500">《隐私政策》</span>
                </span>
              </label>
              {errors.agreeTerms && (
                <p className="flex items-center gap-1 text-red-500 text-xs mt-1">
                  <AlertCircle className="w-3 h-3" />{errors.agreeTerms}
                </p>
              )}
            </div>
          )}

          {/* Submit */}
          <button
            type="submit"
            disabled={isLoading}
            className={cn(
              'w-full py-3 rounded-xl font-medium transition-all flex items-center justify-center gap-2',
              isLoading
                ? 'bg-blue-400 text-white cursor-wait'
                : 'bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg shadow-blue-500/25 hover:shadow-blue-500/40 hover:scale-[1.02] active:scale-[0.98]'
            )}
          >
            {isLoading ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                处理中...
              </>
            ) : mode === 'login' ? (
              <>
                <LogIn className="w-4 h-4" />
                登录
              </>
            ) : (
              <>
                <UserPlus className="w-4 h-4" />
                注册
              </>
            )}
          </button>

          {/* Toggle Mode */}
          <p className="text-center text-sm text-gray-500">
            {mode === 'login' ? '还没有账号？' : '已有账号？'}
            <button
              type="button"
              onClick={() => {
                setMode(mode === 'login' ? 'register' : 'login');
                setErrors({});
              }}
              className="text-blue-500 font-medium hover:text-blue-600 ml-1"
            >
              {mode === 'login' ? '立即注册' : '去登录'}
            </button>
          </p>
        </form>
      </div>
    </div>
  );
}
