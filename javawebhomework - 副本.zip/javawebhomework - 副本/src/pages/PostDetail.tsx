import { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';

function formatTime(dateStr: string): string {
  const now = Date.now();
  const date = new Date(dateStr).getTime();
  const diff = now - date;
  const minutes = Math.floor(diff / 60000);
  if (minutes < 1) return '刚刚';
  if (minutes < 60) return `${minutes}分钟前`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}小时前`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days}天前`;
  const months = Math.floor(days / 30);
  return `${months}个月前`;
}

export default function PostDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { posts, comments, toggleLike, toggleCollect, addComment, user, setShowLoginModal, deletePost } = useApp();
  const [commentText, setCommentText] = useState('');
  const [sortBy, setSortBy] = useState<'latest' | 'hot'>('latest');

  const post = posts.find((p) => p.id === id);
  const postComments = comments[id || ''] || [];

  const sortedComments = sortBy === 'latest'
    ? [...postComments].reverse()
    : [...postComments].sort((a, b) => b.likes - a.likes);

  if (!post) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-16 text-center">
        <span className="text-6xl block mb-4">🔍</span>
        <h2 className="text-2xl font-bold text-gray-900 mb-3">内容不存在</h2>
        <p className="text-gray-500 mb-6">该内容可能已被删除或链接无效</p>
        <Link to="/" className="text-indigo-600 hover:text-indigo-700 font-medium">
          ← 返回首页
        </Link>
      </div>
    );
  }

  const handleComment = () => {
    if (!user) { setShowLoginModal(true); return; }
    if (!commentText.trim()) return;
    addComment(post.id, commentText.trim());
    setCommentText('');
  };

  const isOwner = user && post.userId === user.id;

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-4 sm:py-8">
      {/* Back Button */}
      <button
        onClick={() => navigate(-1)}
        className="flex items-center gap-2 text-sm text-gray-500 hover:text-indigo-600 mb-4 transition-colors group"
      >
        <svg className="w-4 h-4 group-hover:-translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
        </svg>
        返回
      </button>

      {/* Post Detail */}
      <article className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
        {/* Header */}
        <div className="p-6 sm:p-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <span className="text-4xl">{post.avatar}</span>
              <div>
                <p className="font-semibold text-gray-900">{post.username}</p>
                <p className="text-xs text-gray-400">{formatTime(post.createdAt)}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {post.category && (
                <span className="px-3 py-1 bg-indigo-50 text-indigo-600 text-xs font-medium rounded-full">
                  {post.category}
                </span>
              )}
              {isOwner && (
                <button
                  onClick={() => { deletePost(post.id); navigate('/'); }}
                  className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                  title="删除"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                  </svg>
                </button>
              )}
            </div>
          </div>

          {/* Content */}
          <div className="mb-6">
            <p className="text-gray-800 text-[15px] leading-relaxed whitespace-pre-line">{post.content}</p>
          </div>

          {/* Tags */}
          {post.tags && post.tags.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-6">
              {post.tags.map((tag) => (
                <span key={tag} className="px-3 py-1 bg-gray-50 text-gray-500 text-sm rounded-full">
                  #{tag}
                </span>
              ))}
            </div>
          )}

          {/* Actions */}
          <div className="flex items-center gap-3 pt-4 border-t border-gray-100">
            <button
              onClick={() => toggleLike(post.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all duration-200 ${
                post.liked
                  ? 'text-red-500 bg-red-50 hover:bg-red-100'
                  : 'text-gray-500 hover:bg-gray-50 hover:text-red-500'
              }`}
            >
              <svg className="w-5 h-5" fill={post.liked ? 'currentColor' : 'none'} stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={post.liked ? 0 : 2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
              </svg>
              {post.likes} 赞
            </button>

            <button
              onClick={() => toggleCollect(post.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all duration-200 ${
                post.collected
                  ? 'text-amber-500 bg-amber-50 hover:bg-amber-100'
                  : 'text-gray-500 hover:bg-gray-50 hover:text-amber-500'
              }`}
            >
              <svg className="w-5 h-5" fill={post.collected ? 'currentColor' : 'none'} stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={post.collected ? 0 : 2} d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
              </svg>
              {post.collected ? '已收藏' : '收藏'}
            </button>

            <button className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium text-gray-500 hover:bg-gray-50 hover:text-green-500 transition-all duration-200">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
              </svg>
              分享
            </button>
          </div>
        </div>

        {/* Comments Section */}
        <div className="border-t border-gray-100">
          <div className="px-6 sm:px-8 py-4 bg-gray-50/50">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-gray-900">
                评论 <span className="text-indigo-600">({postComments.length})</span>
              </h3>
              <div className="flex items-center gap-2 text-xs">
                <button
                  onClick={() => setSortBy('latest')}
                  className={`px-2 py-1 rounded ${sortBy === 'latest' ? 'text-indigo-600 font-medium' : 'text-gray-400'}`}
                >
                  最新
                </button>
                <button
                  onClick={() => setSortBy('hot')}
                  className={`px-2 py-1 rounded ${sortBy === 'hot' ? 'text-indigo-600 font-medium' : 'text-gray-400'}`}
                >
                  最热
                </button>
              </div>
            </div>
          </div>

          {/* Comment Input */}
          <div className="px-6 sm:px-8 py-4 border-b border-gray-100">
            <div className="flex gap-3">
              <span className="text-2xl mt-1">{user?.avatar || '😊'}</span>
              <div className="flex-1">
                <textarea
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  rows={3}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent text-sm resize-none transition-all"
                  placeholder={user ? '写下你的评论...' : '登录后即可评论'}
                  disabled={!user}
                />
                <div className="flex justify-end mt-2">
                  <button
                    onClick={handleComment}
                    disabled={!commentText.trim() || !user}
                    className="px-4 py-1.5 bg-gradient-to-r from-indigo-600 to-purple-600 text-white text-sm font-medium rounded-lg hover:shadow-md transition-all duration-200 disabled:opacity-40 disabled:cursor-not-allowed"
                  >
                    发表评论
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Comments List */}
          <div className="divide-y divide-gray-50">
            {sortedComments.length > 0 ? (
              sortedComments.map((comment) => (
                <div key={comment.id} className="px-6 sm:px-8 py-4 hover:bg-gray-50/50 transition-colors">
                  <div className="flex gap-3">
                    <span className="text-2xl">{comment.avatar}</span>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium text-sm text-gray-900">{comment.username}</span>
                        <span className="text-xs text-gray-400">{formatTime(comment.createdAt)}</span>
                      </div>
                      <p className="text-sm text-gray-700 leading-relaxed">{comment.content}</p>
                      <div className="flex items-center gap-4 mt-2">
                        <button className="flex items-center gap-1 text-xs text-gray-400 hover:text-red-500 transition-colors">
                          <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                          </svg>
                          {comment.likes}
                        </button>
                        <button className="text-xs text-gray-400 hover:text-indigo-500 transition-colors">
                          回复
                        </button>
                      </div>

                      {/* Replies */}
                      {comment.replies && comment.replies.length > 0 && (
                        <div className="mt-3 pl-4 border-l-2 border-indigo-100 space-y-3">
                          {comment.replies.map((reply) => (
                            <div key={reply.id} className="flex gap-2">
                              <span className="text-lg">{reply.avatar}</span>
                              <div>
                                <div className="flex items-center gap-2 mb-0.5">
                                  <span className="font-medium text-xs text-gray-800">{reply.username}</span>
                                  <span className="text-xs text-gray-400">{formatTime(reply.createdAt)}</span>
                                </div>
                                <p className="text-xs text-gray-600">{reply.content}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="px-6 sm:px-8 py-12 text-center">
                <span className="text-4xl block mb-3">💬</span>
                <p className="text-gray-400 text-sm">暂无评论，快来发表第一条评论吧！</p>
              </div>
            )}
          </div>
        </div>
      </article>
    </div>
  );
}
