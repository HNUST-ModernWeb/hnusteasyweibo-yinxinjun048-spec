import { createContext, useContext, useState, useCallback, ReactNode } from 'react';
import { Post, Comment, Notification, User } from '../types';
import {
  initialPosts,
  initialComments,
  initialNotifications,
  currentUser as defaultUser,
} from '../data/mockData';

interface AppState {
  user: User | null;
  posts: Post[];
  comments: Record<string, Comment[]>;
  notifications: Notification[];
  isLoggedIn: boolean;
  showLoginModal: boolean;
  loginModalTab: 'login' | 'register';
}

interface AppContextType extends AppState {
  login: (username: string, password: string) => boolean;
  register: (username: string, password: string, nickname: string) => boolean;
  logout: () => void;
  setShowLoginModal: (show: boolean) => void;
  setLoginModalTab: (tab: 'login' | 'register') => void;
  toggleLike: (postId: string) => void;
  toggleCollect: (postId: string) => void;
  addPost: (content: string, tags: string[], category: string, images: string[]) => void;
  addComment: (postId: string, content: string, parentId?: string) => void;
  deletePost: (postId: string) => void;
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;
  unreadCount: number;
  getUserById: (id: string) => User | undefined;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(defaultUser);
  const [posts, setPosts] = useState<Post[]>(initialPosts);
  const [comments, setComments] = useState<Record<string, Comment[]>>(initialComments);
  const [notifications, setNotifications] = useState<Notification[]>(initialNotifications);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [loginModalTab, setLoginModalTab] = useState<'login' | 'register'>('login');

  const isLoggedIn = !!user;

  const login = useCallback((username: string, _password: string) => {
    const found = defaultUser;
    if (found) {
      setUser({ ...found, username, nickname: username });
      return true;
    }
    return false;
  }, []);

  const register = useCallback((username: string, _password: string, nickname: string) => {
    setUser({
      ...defaultUser,
      id: `u_${Date.now()}`,
      username,
      nickname: nickname || username,
    });
    return true;
  }, []);

  const logout = useCallback(() => {
    setUser(null);
  }, []);

  const toggleLike = useCallback(
    (postId: string) => {
      if (!user) {
        setShowLoginModal(true);
        return;
      }
      setPosts((prev) =>
        prev.map((p) =>
          p.id === postId
            ? { ...p, liked: !p.liked, likes: p.liked ? p.likes - 1 : p.likes + 1 }
            : p
        )
      );
    },
    [user]
  );

  const toggleCollect = useCallback(
    (postId: string) => {
      if (!user) {
        setShowLoginModal(true);
        return;
      }
      setPosts((prev) =>
        prev.map((p) => (p.id === postId ? { ...p, collected: !p.collected } : p))
      );
    },
    [user]
  );

  const addPost = useCallback(
    (content: string, tags: string[], category: string, images: string[]) => {
      if (!user) return;
      const newPost: Post = {
        id: `p_${Date.now()}`,
        userId: user.id,
        username: user.nickname,
        avatar: user.avatar,
        content,
        images,
        tags,
        likes: 0,
        comments: 0,
        shares: 0,
        liked: false,
        collected: false,
        createdAt: new Date().toISOString(),
        category,
      };
      setPosts((prev) => [newPost, ...prev]);
    },
    [user]
  );

  const addComment = useCallback(
    (postId: string, content: string, _parentId?: string) => {
      if (!user) {
        setShowLoginModal(true);
        return;
      }
      const newComment: Comment = {
        id: `c_${Date.now()}`,
        postId,
        userId: user.id,
        username: user.nickname,
        avatar: user.avatar,
        content,
        createdAt: new Date().toISOString(),
        likes: 0,
        liked: false,
      };
      setComments((prev) => ({
        ...prev,
        [postId]: [...(prev[postId] || []), newComment],
      }));
      setPosts((prev) =>
        prev.map((p) => (p.id === postId ? { ...p, comments: p.comments + 1 } : p))
      );
    },
    [user]
  );

  const deletePost = useCallback((postId: string) => {
    setPosts((prev) => prev.filter((p) => p.id !== postId));
  }, []);

  const markNotificationRead = useCallback((id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  }, []);

  const markAllNotificationsRead = useCallback(() => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  }, []);

  const unreadCount = notifications.filter((n) => !n.read).length;

  const getUserById = useCallback((_id: string) => {
    return undefined;
  }, []);

  return (
    <AppContext.Provider
      value={{
        user,
        posts,
        comments,
        notifications,
        isLoggedIn,
        showLoginModal,
        loginModalTab,
        login,
        register,
        logout,
        setShowLoginModal,
        setLoginModalTab,
        toggleLike,
        toggleCollect,
        addPost,
        addComment,
        deletePost,
        markNotificationRead,
        markAllNotificationsRead,
        unreadCount,
        getUserById,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within AppProvider');
  }
  return context;
}
