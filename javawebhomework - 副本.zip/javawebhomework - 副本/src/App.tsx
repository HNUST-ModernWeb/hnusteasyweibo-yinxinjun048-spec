import { HashRouter, Routes, Route } from 'react-router-dom';
import { AppProvider } from './context/AppContext';
import Navbar from './components/Navbar';
import LoginModal from './components/LoginModal';
import Home from './pages/Home';
import Publish from './pages/Publish';
import Profile from './pages/Profile';
import PostDetail from './pages/PostDetail';
import Search from './pages/Search';

export default function App() {
  return (
    <HashRouter>
      <AppProvider>
        <div className="min-h-screen bg-[#f8f9fb]">
          <Navbar />
          <LoginModal />
          <main>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/publish" element={<Publish />} />
              <Route path="/profile" element={<Profile />} />
              <Route path="/post/:id" element={<PostDetail />} />
              <Route path="/search" element={<Search />} />
            </Routes>
          </main>
          {/* Footer */}
          <footer className="max-w-6xl mx-auto px-4 py-8 mt-8">
            <div className="border-t border-gray-200 pt-8">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-8">
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <span className="text-xl">🚀</span>
                    <span className="font-bold text-gray-900">创意空间</span>
                  </div>
                  <p className="text-sm text-gray-500 leading-relaxed">
                    一个面向学习者的创意社区平台，分享知识、经验和灵感。
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 text-sm mb-3">学习路线</h4>
                  <ul className="space-y-2 text-sm text-gray-500">
                    <li>📐 HTML/CSS/JS 基础</li>
                    <li>⚛️ Vue3 / React 入门</li>
                    <li>☕ Java Web 后端开发</li>
                    <li>🔗 前后端整合实践</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 text-sm mb-3">关于项目</h4>
                  <ul className="space-y-2 text-sm text-gray-500">
                    <li>📋 项目展示页面</li>
                    <li>✏️ 内容发布与编辑</li>
                    <li>👤 用户个人主页</li>
                    <li>💬 评论与互动系统</li>
                  </ul>
                </div>
              </div>
              <div className="text-center text-xs text-gray-400 pt-4 border-t border-gray-100">
                <p>© 2025 创意空间 — 全栈开发学习项目演示</p>
                <p className="mt-1">基于 React + TypeScript + Tailwind CSS 构建</p>
              </div>
            </div>
          </footer>
        </div>
      </AppProvider>
    </HashRouter>
  );
}
