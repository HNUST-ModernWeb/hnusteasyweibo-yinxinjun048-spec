export interface User {
  id: string;
  username: string;
  displayName: string;
  avatar: string;
  bio: string;
  followers: number;
  following: number;
  postCount: number;
  joinDate: string;
  isFollowing?: boolean;
}

export interface Post {
  id: string;
  author: User;
  content: string;
  images: string[];
  tags: string[];
  likes: number;
  isLiked: boolean;
  comments: Comment[];
  commentCount: number;
  shareCount: number;
  createdAt: string;
  bookmarked: boolean;
}

export interface Comment {
  id: string;
  author: User;
  content: string;
  likes: number;
  isLiked: boolean;
  createdAt: string;
  replies?: Comment[];
}

export interface Notification {
  id: string;
  type: 'like' | 'comment' | 'follow' | 'mention';
  fromUser: User;
  content: string;
  postId?: string;
  createdAt: string;
  read: boolean;
}

export type Page = 'home' | 'publish' | 'profile' | 'login' | 'register' | 'post' | 'notifications' | 'explore';
